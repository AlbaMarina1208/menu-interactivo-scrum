import React, { useState } from 'react';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Formulario enviado. ¡Gracias por contactarnos!');
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h2 className="text-3xl font-semibold mb-4">Contáctanos</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input type="text" name="name" placeholder="Tu nombre" value={formData.name} onChange={handleChange} required className="p-2 border rounded" />
        <input type="email" name="email" placeholder="Tu correo" value={formData.email} onChange={handleChange} required className="p-2 border rounded" />
        <textarea name="message" placeholder="Tu mensaje" value={formData.message} onChange={handleChange} required className="p-2 border rounded"></textarea>
        <button type="submit" className="bg-blue-500 text-white py-2 rounded hover:bg-blue-600">Enviar</button>
      </form>
    </div>
  );
};

export default Contact;
