import React from 'react';

const Home = () => {
  return (
    <div className="p-6 text-center">
      <h1 className="text-4xl font-bold mb-2">Clean Up Spaces</h1>
      <p className="text-xl italic mb-4">La limpieza que necesitas, justo a tiempo</p>
      <p className="text-lg">Soluciones de limpieza profesional para oficinas, Airbnb y más.</p>
    </div>
  );
};

export default Home;
