import React from 'react';

const services = [
  { name: "Limpieza Básica", prices: { small: 500, medium: 700, large: 900 } },
  { name: "Limpieza Profunda", prices: { small: 700, medium: 1000, large: 1200 } },
  { name: "Limpieza Post-Evento", prices: { small: 550, medium: 800, large: 1050 } },
  { name: "Limpieza para Oficinas", prices: { small: 550, medium: 800, large: 1050 } },
  { name: "Limpieza para Airbnb", prices: { small: 550, medium: 800, large: 1050 } },
  { name: "Mantenimiento Regular (mensual)", prices: { small: 1200, medium: 2000, large: 2700 } }
];

const Services = () => {
  return (
    <div className="p-6">
      <h2 className="text-3xl font-semibold mb-4">Nuestros Servicios</h2>
      {services.map((service, i) => (
        <div key={i} className="mb-6">
          <h3 className="text-xl font-bold mb-1">{service.name}</h3>
          <ul className="ml-4 list-disc">
            <li>Pequeño (hasta 50 m²): ${service.prices.small}</li>
            <li>Mediano (51 - 100 m²): ${service.prices.medium}</li>
            <li>Grande (+100 m²): ${service.prices.large}</li>
          </ul>
        </div>
      ))}
    </div>
  );
};

export default Services;
